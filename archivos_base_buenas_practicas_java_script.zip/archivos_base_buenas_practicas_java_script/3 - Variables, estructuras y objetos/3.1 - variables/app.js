var mensaje = "¡Hola Mundo!", 
    estado = "activo",
    resultado = 45;