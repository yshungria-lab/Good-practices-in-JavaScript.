var animales = ["perro", "gato", "pez"];

var totalAnimales = animales.length;

try {
     //Acciones a realizar por la excepción
    for (var i = 0; i < totalAnimales; i++) {


    }
} catch (e) {
    //Manejo de errores 
}
