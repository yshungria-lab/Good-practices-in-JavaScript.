var persona = {};
persona.nombre = "Sergio";

var otraPersona = new Object();


var lista = new Array();
lista[0] = "manzana";
lista[1] = "pera";

var listaNueva = ["manzana", "pera"];