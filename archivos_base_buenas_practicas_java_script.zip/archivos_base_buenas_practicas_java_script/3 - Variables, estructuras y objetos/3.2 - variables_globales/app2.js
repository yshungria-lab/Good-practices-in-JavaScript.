var mensaje = "Mensaje global";
resultado = 45;