function myCatch(ball){
	console.log(ball)
}

myCatch("beisball");