var persona = {};

console.log(persona);

if(persona){
	console.log("La persona existe");
} else {
	console.log("La persona NO existe");
}
