var estado = true,
	resultado = "";

if(estado){
	console.log("continuar")
} else {
	console.log("detenerse");
}