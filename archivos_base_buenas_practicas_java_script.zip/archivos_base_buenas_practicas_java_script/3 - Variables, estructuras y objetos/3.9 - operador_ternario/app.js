var estado = true;

// if(estado){
//  console.log("continuar")
// } else {
//  console.log("detenerse");
// }


var accion = estado ? 'continuar' : 'detenerse';

console.log(accion);