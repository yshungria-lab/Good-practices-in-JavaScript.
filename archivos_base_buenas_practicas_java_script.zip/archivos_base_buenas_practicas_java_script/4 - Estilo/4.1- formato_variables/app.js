var nombreCompleto = "Sergio Brito";

var nombre_completo = "Sergio Brito";


function saludarPersona(){

}