var arrAnimales = ["perro", "gato","pez"];

var btnSaludar = document.getElementById("btnSaludar");

var frmRegistro =  document.getElementById("frmRegistro");