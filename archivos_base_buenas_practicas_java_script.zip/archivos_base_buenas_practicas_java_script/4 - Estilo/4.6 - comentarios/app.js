
/**
 * [nombre description]
 * @type {String}
 */
var nombre = "yacafx",
    email = "sergiobritor@gmail.com";

/**
*	Función parar enviar saludos
*	@param {string} nombre - Nombre de la persona a saludar 
**/
function saludar(nombre){
	//Se retorna el mensaje formado
    return "Hola "+ nombre;
}

/*
	Comentario de bloque
*/

// Pruebas
// Pruebas
// Pruebas
// Pruebas


/**
 * @param  {[type]}
 * @param  {[type]}
 * @param  {[type]}
 * @return {[type]}
 */
function calcular(datoA, datoB, datoC){
    var resultado = datoA + datoB;
    return resultado;
}

