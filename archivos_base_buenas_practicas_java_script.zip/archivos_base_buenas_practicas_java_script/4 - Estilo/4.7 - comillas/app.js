var mensaje = "La actividad estuvo 'divertida'";
var mensajeCompleto = 'La actividad estuvo "divertida"';

console.log(mensaje);
console.log(mensajeCompleto);