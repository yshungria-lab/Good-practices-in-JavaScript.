//window.onload = function() {
    var btnSaludar = document.getElementById("btnSaludar");

    btnSaludar.addEventListener('click', function() {
        console.log("¡Hola Mundo!");
    });
//}