var estado = true;

if(estado)
	console.log("avanzar");
	var resultado = 2+2;

if(estado){
	console.log("avanzar");
}

var resultado = 2+2;