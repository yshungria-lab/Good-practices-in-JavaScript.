var animales = ["perro", "gato", "pez"];

var listaAnimales = animales.join(", ");

var nuevaLista = animales.concat(",");

console.log(listaAnimales);
console.log(typeof listaAnimales);

console.log(nuevaLista);
console.log(typeof nuevaLista);