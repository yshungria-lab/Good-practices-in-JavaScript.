var _0x5dcc=["\x54\x69\x65\x6E\x64\x61\x20\x6C\x61\x73\x20\x34\x20\x65\x73\x71\x75\x69\x6E\x61\x73","\x48\x6F\x6C\x61\x20","\x62\x74\x6E\x53\x61\x6C\x75\x64\x61\x72","\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x42\x79\x49\x64","\x63\x6C\x69\x63\x6B","\x73\x61\x6C\x75\x64\x61\x72","\x6C\x6F\x67","\x61\x64\x64\x45\x76\x65\x6E\x74\x4C\x69\x73\x74\x65\x6E\x65\x72"];var tienda={nombre:_0x5dcc[0],calcular:function(_0x31fex2,_0x31fex3){return _0x31fex2+_0x31fex3},saludar:function(){var _0x31fex4=_0x5dcc[1];return _0x31fex4;}};var btnSaludar=document[_0x5dcc[3]](_0x5dcc[2]);btnSaludar[_0x5dcc[7]](_0x5dcc[4],function(){console[_0x5dcc[6]](tienda[_0x5dcc[5]]())});

console.log("Nuestro código ha sido ofuscado");
console.log(tienda.nombre);
console.log(tienda.calcular(20, 32));
console.log(tienda.saludar());